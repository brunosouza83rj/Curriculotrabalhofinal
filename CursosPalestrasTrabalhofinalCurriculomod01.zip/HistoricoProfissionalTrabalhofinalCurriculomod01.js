import React from 'react';

const HistoricoProfissional = () => {
  return (
    <div>
      <h2>Histórico Profissional</h2>
      <ul>
        <li>Desenvolvedor Fullstack - Empresa ABC (2021-presente)</li>
        <li>Desenvolvedor Web - Empresa DEF (2019-2021)</li>
      </ul>
    </div>
  );
};

export default HistoricoProfissional;
