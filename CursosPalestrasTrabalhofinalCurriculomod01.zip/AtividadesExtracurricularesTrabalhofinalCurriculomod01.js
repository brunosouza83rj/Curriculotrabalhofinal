import React from 'react';

const AtividadesExtracurriculares = () => {
  return (
    <div>
      <h2>Atividades Extracurriculares</h2>
      <ul>
        <li>Contribuições em projetos Open Source</li>
        <li>Hackathons</li>
      </ul>
    </div>
  );
};

export default AtividadesExtracurriculares;
