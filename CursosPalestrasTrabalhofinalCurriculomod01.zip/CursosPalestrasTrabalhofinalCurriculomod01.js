import React from 'react';

const CursosPalestras = () => {
  return (
    <div>
      <h2>Cursos e Palestras</h2>
      <ul>
        <li>Curso de React - Udemy (2020)</li>
        <li>Palestra: Tendências em Desenvolvimento Web - Conferência XYZ (2022)</li>
      </ul>
    </div>
  );
};

export default CursosPalestras;
