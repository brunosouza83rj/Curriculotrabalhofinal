document.getElementById('cadastroUsuarioForm').addEventListener('submit', function (e) {
    e.preventDefault();

    const nome = document.getElementById('nome').value;
    const cpf = document.getElementById('cpf').value;
    const email = document.getElementById('email').value;
    const telefone = document.getElementById('telefone').value;

    const usuario = {
        nome: nome,
        cpf: cpf,
        email: email,
        telefone: telefone
    };

    let usuarios = JSON.parse(localStorage.getItem('usuarios')) || [];
    usuarios.push(usuario);

    localStorage.setItem('usuarios', JSON.stringify(usuarios));

    alert('Locador cadastrado com sucesso!');
    document.getElementById('cadastroUsuarioForm').reset();
});
